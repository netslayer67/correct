import React from 'react';
import { motion } from 'framer-motion';

const cardVariants = {
  hidden: { opacity: 0, y: 40 },
  visible: (i) => ({
    opacity: 1,
    y: 0,
    transition: {
      delay: i * 0.15,
      duration: 0.6,
      ease: "easeOut"
    }
  })
};

const ValuePropsSection = ({ valueProps }) => {
  return (
    <section id="about" className="relative py-28 bg-gradient-to-b from-blue-950 via-sky-900 to-blue-950 overflow-hidden">
      {/* Decorative Glow / Blur */}
      <div className="absolute inset-0 -z-10 backdrop-blur-lg bg-white/5" />
      <div className="container-max text-white">
        {/* Header */}
        <motion.div
          className="text-center max-w-3xl mx-auto mb-20"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight leading-snug mb-4">
            Pilar Pembelajaran di <span className="text-sky-400">Correctly</span>
          </h2>
          <p className="text-lg text-white/80 font-light">
            Kami membangun fondasi belajar yang kokoh di atas tiga nilai utama untuk memastikan kesuksesan setiap murid.
          </p>
        </motion.div>

        {/* Value Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {valueProps.map((prop, index) => (
            <motion.div
              key={prop.title}
              custom={index}
              variants={cardVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="relative p-8 bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl shadow-md transition-all hover:shadow-xl hover:border-white/20 group"
            >
              <div className="mb-6 flex items-center justify-center w-14 h-14 rounded-full bg-sky-500/10 text-sky-300 group-hover:bg-sky-500/20 transition-all">
                {prop.icon}
              </div>
              <h3 className="text-xl font-semibold mb-3 tracking-wide group-hover:text-white text-white/90">
                {prop.title}
              </h3>
              <p className="text-white/70 font-light leading-relaxed">
                {prop.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ValuePropsSection;
