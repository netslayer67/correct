import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Toaster } from '@/components/ui/toaster';
import { toast } from '@/components/ui/use-toast';

import { tutors, testimonials, howItWorksSteps, valueProps, pricingPlans } from '@/data/landingData';

import Navbar from '@/components/landing/Navbar';
import HeroSection from '@/components/landing/HeroSection';
import ValuePropsSection from '@/components/landing/ValuePropsSection';
import HowItWorksSection from '@/components/landing/HowItWorksSection';
import TutorsSection from '@/components/landing/TutorsSection';
import PricingSection from '@/components/landing/PricingSection';
import TestimonialsSection from '@/components/landing/TestimonialsSection';
import CtaSection from '@/components/landing/CtaSection';
import Footer from '@/components/landing/Footer';
import PageLoader from '@/components/ui/PageLoader';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  const handleCTAClick = (action) => {
    toast({
      title: "🚧 Fitur Dalam Pengembangan",
      // description: "Fitur ini belum siap, tapi Anda bisa memintanya di prompt berikutnya! 🚀",
      duration: 3000,
    });
  };

  useEffect(() => {
    const loadedBefore = localStorage.getItem("correctly-loaded");
    if (loadedBefore) {
      setIsLoading(false);
    } else {
      const timer = setTimeout(() => {
        setIsLoading(false);
        localStorage.setItem("correctly-loaded", "true");
      }, 2200);
      return () => clearTimeout(timer);
    }
  }, []);

  if (isLoading) return <PageLoader />;

  return (
    <>
      <Helmet>
        <title>Correctly - Learn English with Professional Tutors</title>
        <meta
          name="description"
          content="Pesan guru bahasa Inggris profesional untuk sesi online atau tatap muka. Belajar dengan pendekatan personal, jadwal fleksibel, dan kualitas terjamin."
        />
        <html lang="id" />
        <link rel="icon" type="image/svg+xml" href="/favicon.svg" />
      </Helmet>

      <div className="bg-background text-foreground font-sans">
        <Navbar
          isMenuOpen={isMenuOpen}
          setIsMenuOpen={setIsMenuOpen}
          scrollToSection={scrollToSection}
          handleCTAClick={handleCTAClick}
        />

        <main>
          <HeroSection scrollToSection={scrollToSection} />
          <ValuePropsSection valueProps={valueProps} />
          <HowItWorksSection steps={howItWorksSteps} />
          <TutorsSection tutors={tutors} handleCTAClick={handleCTAClick} />
          <PricingSection plans={pricingPlans} handleCTAClick={handleCTAClick} />
          <TestimonialsSection testimonials={testimonials} />
          <CtaSection handleCTAClick={handleCTAClick} />
        </main>

        <Footer scrollToSection={scrollToSection} />
        <Toaster />
      </div>
    </>
  );
}

export default App;
